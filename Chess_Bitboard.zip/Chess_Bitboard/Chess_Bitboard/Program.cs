﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Chess_Bitboard;

namespace Chess_Bitboard
{
    class Program
    {
        static void Main(string[] args)
        {
            ChessBoard.initiateBoard();
        }
    }
}
